#include <iostream>
#include <string>
#include "model/sdd/vector3d.hpp"
#include "model/elements/atomes.hpp"

int main(int argc, char* argv[]) {

    // region test Vector3D

    Vector3D<double> v1(1, 2, 3);

    std::cout << v1 << std::endl;
    std::cout << v1.norme() << std::endl;

    v1.set_x(4);
    v1.set_y(5);
    v1.set_z(6);

    std::cout << v1.get_x() << ", " << v1.get_y() << ", " << v1.get_z() << std::endl;

    Vector3D<std::string> v2("a", "b", "c");
    std::cout << v2.get_x() << ", " << v2.get_y() << ", " << v2.get_z() << std::endl;
//    std::cout << v2.norme() << std::endl;

    Vector3D<double> v3(6,5,4);
    Vector3D<double> v4 = (v1 + v3); // = v1;
    double scal = v1 * v3;

    std::cout << v4.get_x() << ", " << v4.get_y() << ", " << v4.get_z() << std::endl;
    std::cout << scal << std::endl;

    // endregion

    //region test atome

    //Atome atm(v1, "O");
    //atm.affiche_atome();
    //endregion


    return 0;
}
